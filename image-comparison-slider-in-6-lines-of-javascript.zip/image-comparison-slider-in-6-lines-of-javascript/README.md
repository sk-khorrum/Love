# Image Comparison Slider in 6 lines of JavaScript

A Pen created on CodePen.

Original URL: [https://codepen.io/stanko/pen/myddXKm](https://codepen.io/stanko/pen/myddXKm).

